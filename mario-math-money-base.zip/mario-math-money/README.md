# 🍄 Mario Math: Money – Year 4 DSKP
## Base Scaffold for Jules AI

---

### 📁 Project Structure

```
mario-math-money/
├── index.html          ← Home / World Map
├── css/
│   └── main.css        ← All styles (tokens, components, worlds)
├── js/
│   └── main.js         ← Coin system, localStorage, question engine
└── pages/
    ├── world1.html     ← DSKP 4.1.1 · Recognise Money
    ├── world2.html     ← DSKP 4.1.2 · Add Money
    ├── world3.html     ← DSKP 4.1.3 · Subtract Money
    ├── world4.html     ← DSKP 4.1.4 · Multiply Money
    ├── world5.html     ← DSKP 4.1.5 · Divide Money
    └── world6.html     ← DSKP 4.1.6 · Mixed Problems (Boss Level)
```

---

### 🎯 DSKP Coverage

| World | DSKP Code | Topic                          |
|-------|-----------|-------------------------------|
| 1-1   | 4.1.1     | Recognise coins and notes      |
| 1-2   | 4.1.2     | Add amounts up to RM100        |
| 1-3   | 4.1.3     | Subtract / calculate change    |
| 1-4   | 4.1.4     | Multiply by 1-digit number     |
| 1-5   | 4.1.5     | Divide by 1-digit number       |
| BOSS  | 4.1.6     | Real-world mixed problems      |

---

### 🔌 JavaScript API (window.MarioMath)

```js
MarioMath.initQuestion({
  containerId:    'q1',         // id of the .activity-card element
  answers:        ['A','B','C','D'],
  correctIndex:   2,            // 0-based index of correct answer
  worldKey:       'world1',     // key for localStorage
  coinsOnCorrect: 1             // coins awarded for correct answer
});

MarioMath.addCoins('world1', 3);   // saves best score per world
MarioMath.totalCoins();            // returns total coins across all worlds
MarioMath.getProgress();           // returns { world1: 2, world2: 1, ... }
```

---

### 🏗️ Design Tokens (CSS Variables)

```css
--mario-red:      #E52222
--mario-blue:     #1A6DFF
--sky-blue:       #5B9EE8
--grass-green:    #2D8A1F
--coin-gold:      #F5C518
--coin-gold-dark: #C99A00
--brick-brown:    #8B4513
--ui-bg:          #0D1B6E
--font-pixel:     'Press Start 2P'
--font-body:      'Nunito'
--radius-card:    12px
--shadow-card:    0 6px 0 rgba(0,0,0,0.35)
```

---

### 📋 HTML Component Patterns

#### Multiple-choice question card
```html
<div class="activity-card" id="qN">
  <p class="activity-title">❓ Question N</p>
  <div class="question-block">
    [question text]
  </div>
  <div class="answer-choices">
    <button class="choice-btn">A</button>
    <button class="choice-btn">B</button>
    <button class="choice-btn">C</button>
    <button class="choice-btn">D</button>
  </div>
  <div class="feedback-box"></div>
</div>
```

#### Coin reward badge
```html
<span class="coin-reward">🪙 +1</span>
```

#### DSKP reference tag
```html
<div class="dskp-ref">DSKP 4.1.X</div>
```

---

### 🚀 Extension Points for Jules AI

1. **Drag-and-drop coin counting** – add to world1.html (visual coin recognition)
2. **Animated shop interactions** – drag items into a cart with running total
3. **Hint system** – add a 💡 button that reveals a step-by-step working
4. **Timer / speed challenge mode** – add a countdown for bonus coins
5. **Certificate / printable** – unlock when all 6 worlds complete (18 coins)
6. **Sound effects** – coin collect, wrong answer buzz, level complete fanfare
7. **More questions** – each world currently has 3 questions; expand to 5–10
8. **BM language toggle** – add Bahasa Malaysia translations of all questions
9. **Teacher dashboard** – read localStorage data across sessions
10. **Animated score counter** – coin tally increments with animation on correct

---

### 🎨 Fonts (Google Fonts – already linked)

- **Press Start 2P** – pixel/retro game headings
- **Nunito** – friendly rounded body text, great for children

---

### 📦 No build tools required
Pure HTML/CSS/JS. Open `index.html` directly in any browser. No npm, no bundler.
