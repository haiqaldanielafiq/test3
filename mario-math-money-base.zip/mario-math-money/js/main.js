/* ============================================
   MARIO MATH: MONEY – main.js
   Coin tracking + progress persistence
   ============================================ */

const WORLDS = ['world1', 'world2', 'world3', 'world4', 'world5', 'world6'];
const MAX_COINS_PER_WORLD = 3;   // adjust when adding activities

// ── Storage helpers ──────────────────────────
function getProgress() {
  try {
    return JSON.parse(localStorage.getItem('marioMathMoney') || '{}');
  } catch { return {}; }
}

function saveProgress(data) {
  try { localStorage.setItem('marioMathMoney', JSON.stringify(data)); } catch {}
}

function addCoins(worldKey, coins) {
  const data = getProgress();
  data[worldKey] = Math.max(data[worldKey] || 0, coins);   // keep best score
  saveProgress(data);
  return totalCoins(data);
}

function totalCoins(data) {
  data = data || getProgress();
  return Object.values(data).reduce((a, b) => a + b, 0);
}

function completedWorlds(data) {
  data = data || getProgress();
  return WORLDS.filter(w => (data[w] || 0) >= MAX_COINS_PER_WORLD).length;
}

// ── UI update (index page) ───────────────────
function refreshHomeUI() {
  const data = getProgress();

  const coinEl = document.getElementById('total-coins');
  if (coinEl) coinEl.textContent = totalCoins(data);

  const fillEl = document.getElementById('progress-fill');
  const pctEl  = document.getElementById('progress-pct');
  if (fillEl && pctEl) {
    const pct = Math.round((completedWorlds(data) / WORLDS.length) * 100);
    fillEl.style.width = pct + '%';
    fillEl.closest('[role="progressbar"]')?.setAttribute('aria-valuenow', pct);
    pctEl.textContent = pct + '%';
  }
}

// ── Question helper (used on world pages) ────
function initQuestion({ containerId, answers, correctIndex, worldKey, coinsOnCorrect = 1 }) {
  const container = document.getElementById(containerId);
  if (!container) return;

  const buttons  = container.querySelectorAll('.choice-btn');
  const feedback = container.querySelector('.feedback-box');
  let answered = false;

  buttons.forEach((btn, i) => {
    btn.addEventListener('click', () => {
      if (answered) return;
      answered = true;

      if (i === correctIndex) {
        btn.classList.add('correct');
        feedback.textContent = '⭐ Correct! Well done! +' + coinsOnCorrect + ' coin' + (coinsOnCorrect > 1 ? 's' : '') + '!';
        feedback.className = 'feedback-box show ok';
        const total = addCoins(worldKey, coinsOnCorrect);
        updateInPageCoin(total);
      } else {
        btn.classList.add('wrong');
        buttons[correctIndex].classList.add('correct');
        feedback.textContent = '❌ Not quite! The answer is ' + answers[correctIndex] + '. Try the next one!';
        feedback.className = 'feedback-box show fail';
      }
    });
  });
}

function updateInPageCoin(total) {
  const el = document.getElementById('page-coins');
  if (el) el.textContent = total;
}

// ── Boot ─────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  refreshHomeUI();

  // Sync coin counter on world pages
  const data = getProgress();
  updateInPageCoin(totalCoins(data));
});

// Expose for world pages
window.MarioMath = { initQuestion, addCoins, getProgress, totalCoins };
